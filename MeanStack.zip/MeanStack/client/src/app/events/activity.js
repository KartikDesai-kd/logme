"use strict";
var Activity = (function () {
    function Activity() {
    }
    return Activity;
}());
exports.Activity = Activity;
//# sourceMappingURL=activity.js.map