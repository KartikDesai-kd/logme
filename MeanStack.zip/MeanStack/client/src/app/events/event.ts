export class Event{
    username:string;
    activity:string;
    loggedin:number;
    activitytime:Date;
}