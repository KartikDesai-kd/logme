export class Activity{
    username:string;
    activity:string;
    loggedin:number;
    activitytime:Date;
}