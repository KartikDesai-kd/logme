"use strict";
var Signup = (function () {
    function Signup() {
    }
    return Signup;
}());
exports.Signup = Signup;
//# sourceMappingURL=signup.js.map