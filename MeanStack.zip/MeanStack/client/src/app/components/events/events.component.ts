import { Component } from '@angular/core';
import { Router,NavigationExtras } from '@angular/router';
import {ActivatedRoute} from '@angular/router';
import {EventService } from '../../services/events/event.service';
import {ActivityService } from '../../services/events/activity.service';
import {Event} from '../../events/event';

@Component({
  moduleId:module.id,
  selector: 'events',
  templateUrl:'events.component.html'

})

export class EventsComponent  {
        valid: boolean=false;
         events: Event[];
         firstname:string;
         lastname:string;
       // status="11";
       constructor(private route: ActivatedRoute,private eventService:EventService,private router: Router,private activityService:ActivityService) {
         console.log("in const");
          this.eventService.getTasks()
            .subscribe(events=>{
                this.events=events;
               console.log(events);
        //       console.log("events log: "+this.events[0].loggedin);
               
            });
        //    console.log("events: "+this.events);
       }
       ngOnInit() {
        // Capture the token  if available
       console.log("user: in evetns: "+localStorage.getItem('currentUser'));
       this.firstname=localStorage.getItem('firstname');
       this.lastname=localStorage.getItem('lastname');
       this.valid = this.route.snapshot.queryParams['valid'];
      console.log("fname : "+this.firstname);
    }
    
    editlog(task){
        var logcount=parseInt(task.loggedin)+1;
        console.log("log count: "+logcount);
        var _task = {
            _id:task._id,
            username: task.username,
            activity: task.activity,
            loggedin:logcount
        };
        
        this.activityService.editActivity(_task).subscribe(data => {
            console.log("data: "+JSON.stringify(data));
            this.eventService.getTasks()
            .subscribe(events=>{
                this.events=events;
               console.log("display event: "+JSON.stringify(events));
              console.log("events log: "+this.events.loggedin);
            });
           this.router.navigate(['/events'],{ queryParams: { valid:true}})
        });
    }

    viewoccurrence(occur){
             console.log("id: "+occur);
             // var tasks = this.tasks;
            //  console.log("id: "+this.id);    
              this.router.navigate(['/viewoccurrence'],{ queryParams: { id:occur}})
    } 
}