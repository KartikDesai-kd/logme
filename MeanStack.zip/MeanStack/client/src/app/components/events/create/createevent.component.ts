import { Component } from '@angular/core';
import { Router,NavigationExtras } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivityService } from '../../../services/events/activity.service';
import {Activity} from '../../../events/activity';


@Component({
  moduleId:module.id,
  selector: 'createevent',
  templateUrl:'createevent.component.html'

})

export class CreateeventComponent  {

    complexForm : FormGroup;
    activityinfo: Activity[];
    username:string;
    activity:string;
    loggedin:number=0;
    activitytime:Date;
    firstname:string;
    lastname:string;
    constructor(fb: FormBuilder,private activityService:ActivityService,private router: Router){
    
    this.complexForm = fb.group({
    // To add a validator, we must first convert the string value into an array. The first item in the array is the default value if any, then the next item in the array is the validator. Here we are adding a required validator meaning that the firstName attribute must have a value in it.
    'activity' : [null, Validators.required]
  })

      this.firstname=localStorage.getItem('firstname');
       this.lastname=localStorage.getItem('lastname');
}    
   // password:string;
  /*      valid: boolean=false;
       // status="11";
       constructor(private route: ActivatedRoute) {}
       ngOnInit() {
    // Capture the token  if available
    this.valid = this.route.snapshot.queryParams['valid']
    console.log("status : "+this.valid);
} */

addActivity(event){
       event.preventDefault();
       console.log(this.activity);
       var newActivity={
           username:localStorage.getItem('currentUser'),
           activity:this.activity,
           loggedin:this.loggedin
       }
      
       this.activityService.addActivity(newActivity)
           .subscribe(activity=>{
             //  this.signupinfo.push(newSignup);
              // localStorage.setItem('currentUser',this.username);
               this.activity='';
           /*    let navigationExtras: NavigationExtras = {
                queryParams: {
                "user": "yes" 
            }
        };*/
           this.router.navigate(['/events'],{ queryParams: { valid:true}})
            });
    //    this.router.navigateByUrl('/events', navigationExtras);
       //   this.router.navigate(['/events'])
            //   this.router.navigateByUrl('/events', { queryParams: { user: "yes" } });
        //   }); 
    }

submitForm(value: any){
  console.log(value);
} 
}