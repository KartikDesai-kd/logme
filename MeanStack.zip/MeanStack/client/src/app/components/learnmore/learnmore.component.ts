import { Component } from '@angular/core';

@Component({
  moduleId:module.id,
  selector: 'learnmore',
  templateUrl:'learnmore.component.html'

})

export class LearnmoreComponent  {
        
}