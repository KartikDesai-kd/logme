import { Component } from '@angular/core';

@Component({
  moduleId:module.id,
  selector: 'home',
  templateUrl:'home.component.html'

})

export class HomeComponent  {
        status:string;

     constructor()
     {
       console.log("status: "+this.status);
     }   
}