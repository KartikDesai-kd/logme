export class Signin{
    username:string;
    password:string;
}