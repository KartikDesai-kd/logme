"use strict";
var Signin = (function () {
    function Signin() {
    }
    return Signin;
}());
exports.Signin = Signin;
//# sourceMappingURL=signin.js.map