var mongoose = require( 'mongoose' );
var Schema   = mongoose.Schema;

var ActivitySchema = new Schema({
    username    : String,
    activity : String,
    loggedin : Number,
    activitytime : Date
});

//mongoose.model( 'MyTask', MyTask );
module.exports = mongoose.model( 'ActivityInfo', ActivitySchema );
//mongoose.connect( 'mongodb://localhost/Tasks' );